from django.db import models
from apps.concensus.domain.entities.group import Group
from apps.concensus.domain.entities.topic import Topic
from apps.concensus.domain.entities.notification import NotificationPhaseOne
from apps.concensus.domain.entities.user_expertice import UserExpertise
from apps.concensus.domain.entities.notification import NotificationPhaseTwo
from apps.concensus.domain.entities.final_topic_order import FinalTopicOrder
from apps.concensus.domain.entities.user_phase import UserPhase
from apps.concensus.domain.entities.result_concensus import ConsensusResult
from apps.concensus.domain.entities.user_satisfaction import UserSatisfaction

# Create your models here.
