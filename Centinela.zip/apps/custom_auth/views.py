from apps.custom_auth.infrastructure.api.v1.views.group_views import GroupListCreateView
from apps.custom_auth.infrastructure.api.v1.views.post_views import PostListView, PostCreateView, PostDeleteView
from apps.custom_auth.infrastructure.api.v1.views.profile_information_views import ProfileInformationDetailView, PublicProfileInformationDetailView
from apps.custom_auth.infrastructure.api.v1.views.user_views import UserListView, UserUpdateView, UserTokenObtainPairView, UserDetailView, RegisterView
